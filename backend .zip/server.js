// server.js
const express = require("express");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Root route
app.get("/", (req, res) => {
  res.send("✅ Backend is working!");
});

// Example chatbot route
app.post("/message", (req, res) => {
  const userMessage = req.body.message?.toLowerCase();
  let reply = "I don't understand.";
  
  if (userMessage.includes("hi")) reply = "Hello!";
  if (userMessage.includes("how are you")) reply = "I'm good, thanks!";
  
  res.json({ reply });
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
